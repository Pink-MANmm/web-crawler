import time
import requests
from lxml import etree
import re
import pandas as pd
from loguru import logger
from datetime import datetime
import json

class sc():
    def __init__(self,page):
        '''初始化'''
        self.page=page
        self.url1='http://xinjiang.gov.cn/communication/api-mailbox/frontMail/mailList'
        self.url2='http://xinjiang.gov.cn/communication/api-mailbox/frontMail/detail?mailId='
        self.id=[]
        self.headers1={
            'Host': 'xinjiang.gov.cn',#关键参数
            'Content-Type': 'application/json;charset=UTF-8',#关键参数
            'cookie':'yfx_c_g_u_id_10000001=_ck22062415055819031431786191535; JSESSIONID=8E7DC25252BBF875954DDA6C68249E37; security_session_verify=90a00b3538034923700820ef32aab802; yfx_f_l_v_t_10000001=f_t_1656054358894__r_t_1656054358894__v_t_1656056187503__r_c_0',
            'User-Agent':'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/103.0.0.0 Safari/537.36',
        }
        self.headers2={
            'cookie':'yfx_c_g_u_id_10000001=_ck22062415055819031431786191535; yfx_f_l_v_t_10000001=f_t_1656054358894__r_t_1656054358894__v_t_1656071544096__r_c_0; JSESSIONID=2A2A6502EAC3CB784B86D31ED18CB346; security_session_verify=a1c60e6fe1c2cd9828c0b744482fc6ed',
            'User-Agent':'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/103.0.0.0 Safari/537.36'
        }
        self.payload_data={
            "pageNum":1,
            "pageSize":20,
            "sortMap":{"createTime":"desc"},
            "params":{"phone":"",
                      "searchCode":"",
                      "deptId":"bd2fb76fc7314b3088b5459bb0bc4f71"}
        }
        self.consultIndex=[]
        self.consultCategory = []
        self.consultTitle=[]
        self.consultContent = []
        self.consultName = []
        self.consultDate = []
        self.consultId = []
        self.consultState = []
        self.answerDate = []
        self.answerContent = []
        self.df = pd.DataFrame()
        self.currentYear=datetime.now().year
    def send1(self):
        '''发送请求'''
        self.id=[]
        info=requests.post(self.url1,headers=self.headers1,data=json.dumps(self.payload_data))
        if info.status_code==200:
            Info = info.text
            Id = json.loads(Info)
            for i in Id['data']['rows']:
                self.id.append(i['id'])
            return
    def send2(self,url):
        '''发送请求'''
        info = requests.get(url, headers=self.headers2)
        if info.status_code == 200:
            return info
    def spider(self):
        '''业务处理'''
        logger.info('开始启动爬虫')
        for pageNumber in range(1,self.page+1):
            logger.info('当前正在爬取第' + str(pageNumber) + '页')
            self.payload_data['pageNum']=pageNumber
            self.send1()
            for message in range(1,len(self.id)+1):
                info=self.send2(self.url2+str(self.id[message-1]))
                Data=json.loads(info.text)
                data=Data['data']
                askCategory=''.join(re.findall(r'[\u4e00-\u9fa5]',str(data['objectiveType'])))
                askTitle=''.join(re.findall(r'[\u4e00-\u9fa5]',str(data['title'])))
                askContent=''.join(re.findall(r'[\u4e00-\u9fa5]',str(data['content'])))
                askName=''.join(re.findall(r'[\u4e00-\u9fa5]',str(data['fromName'])))
                askDate=''.join(str(data['createTime']))
                askId=''.join(str(data['serialNumber']))
                askState=''.join(re.findall(r'[\u4e00-\u9fa5]',str(data['status'])))
                replyDate=''.join(str(data['replyContents'][0]['replyTime']))
                html=etree.HTML(str(data['replyContents'][0]['replyContent']))
                Content=html.xpath('//p/span')
                replyContent=[]
                for i in Content:
                    replyContent.append(''.join(re.findall(r'[\u4e00-\u9fa5]',str(i.text))))
                '''去重'''
                if askDate not in self.consultDate and (int(askDate[0:4])>=int(self.currentYear-10)):
                    self.consultCategory.append(str(askCategory))
                    self.consultName.append(askName)
                    self.consultDate.append(askDate)
                    self.consultId.append(askId)
                    self.consultTitle.append(askTitle)
                    self.consultContent.append(askContent)
                    self.consultState.append(askState)
                    self.answerDate.append(replyDate)
                    self.answerContent.append(replyContent)
                else:
                    logger.info('数据更新完毕')
                    logger.info('下一次数据采集将在一小时后')
                    self.save()
                    '''实现增量，源源不断获取最新版本的数据文件'''
                    self.df.to_excel('hd.xlsx')
                    self.df.drop(self.df.index, inplace=True)
                    time.sleep(60*60)
                    '''每一小时采集一次数据'''
                    self.spider()
        return

    '''每一小时采集一次数据'''
    def save(self):
        '''保存'''
        self.df['consultCategory'] = self.consultCategory
        self.df['consultTitle'] = self.consultTitle
        self.df['consultName']=self.consultName
        self.df['consultDate']=self.consultDate
        self.df['consultId']=self.consultId
        self.df['consultState']=self.consultState
        self.df['consultContent']=self.consultContent
        self.df['answerDate']=self.answerDate
        self.df['answerContent']=self.answerContent
        return

    def run(self):
        '''入口函数'''
        while True:
            self.spider()
        return
if __name__=='__main__':
    page=1000
    sc(page).run()

